# micrometer-hello-service-2023

![Diagram](./gif/diagram.gif)